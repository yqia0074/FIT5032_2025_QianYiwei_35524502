<template>
  <div class="my-4">
    <h3>Emotional Support Hub</h3>
    <p>Today's featured meditation video:</p>
    <iframe width="100%" height="315" src="https://www.youtube.com/embed/inpok4MKVLM" frameborder="0" allowfullscreen></iframe>
    <p class="mt-2">Or listen to our daily encouragement audio below:</p>
    <audio controls>
      <source src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" type="audio/mpeg" />
      Your browser does not support the audio element.
    </audio>
  </div>
</template>

<script setup>
</script>



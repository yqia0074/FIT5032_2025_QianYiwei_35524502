<template>
  <div class="container mt-5 text-center">
    <h2>Welcome to Psych Support</h2>
    <p>Please choose to log in if you already have an account, or register as a new user.</p>
    <div class="mt-4">
      <router-link to="/login" class="btn btn-primary me-3">Login</router-link>
      <router-link to="/register" class="btn btn-outline-secondary">Register</router-link>
    </div>
  </div>
</template>

<script setup>
</script>

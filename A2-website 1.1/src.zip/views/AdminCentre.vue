<template>
  <div class="container mt-4">
    <h2>Admin Centre</h2>
    <Community />
    <EmailCenter />
    <AnalyticsTables />
  </div>
</template>

<script setup>
import Community from '../components/Community.vue'
import EmailCenter from '../components/EmailCenter.vue'
import AnalyticsTables from '../components/AnalyticsTables.vue'
</script>



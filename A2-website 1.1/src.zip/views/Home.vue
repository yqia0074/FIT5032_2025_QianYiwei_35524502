<template>
  <div class="container mt-5">

    <!-- Welcome section -->
    <h1>Welcome to Psych Support Platform</h1>
    <p>
      This platform provides mental health support, self-help tools, and community sharing for teenagers, workers, and administrators.
    </p>
    <router-link to="/auth" class="btn btn-primary mt-3">Login / Register</router-link>

    <!-- About us section -->
    <section class="my-5">
      <h2>About Us</h2>
      <p>
        We aim to help people improve their mental well-being through community stories, self-help tools, and professional support resources. Our mission is to build a safe, supportive, and inclusive space for everyone.
      </p>
    </section>

    <!-- Carousel section -->
    <section class="my-5">
      <h2>Latest Announcements</h2>
      <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active"></button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"></button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="https://via.placeholder.com/800x300?text=Announcement+1" class="d-block w-100" alt="Announcement 1">
          </div>
          <div class="carousel-item">
            <img src="https://via.placeholder.com/800x300?text=Announcement+2" class="d-block w-100" alt="Announcement 2">
          </div>
          <div class="carousel-item">
            <img src="https://via.placeholder.com/800x300?text=Announcement+3" class="d-block w-100" alt="Announcement 3">
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
          <span class="carousel-control-prev-icon"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
          <span class="carousel-control-next-icon"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </section>

  </div>
</template>

<script setup>
</script>




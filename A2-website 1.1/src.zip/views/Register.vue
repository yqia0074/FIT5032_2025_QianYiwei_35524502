<template>
  <div class="container mt-5">
    <h2>Register</h2>
    <form @submit.prevent="register">
      <div class="mb-3">
        <input v-model="email" type="email" placeholder="Email" class="form-control" required>
      </div>
      <div class="mb-3">
        <input v-model="password" type="password" placeholder="Password" class="form-control" required>
      </div>
      <div class="mb-3">
        <select v-model="role" class="form-select" required>
          <option disabled value="">Select role</option>
          <option value="teenager">Teenager</option>
          <option value="worker">Worker</option>
          <option value="admin">Admin</option>
        </select>
      </div>
      <button type="submit" class="btn btn-primary">Register</button>
    </form>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const email = ref('')
const password = ref('')
const role = ref('')
const router = useRouter()

function register() {
  const newUser = {
    email: email.value,
    password: password.value,
    role: role.value
  }

  localStorage.setItem('user', JSON.stringify(newUser))

  if (role.value === 'teenager') {
    router.push('/teenager-centre')
  } else if (role.value === 'worker') {
    router.push('/worker-centre')
  } else if (role.value === 'admin') {
    router.push('/admin-centre')
  }
}
</script>


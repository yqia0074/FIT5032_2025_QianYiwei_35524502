<template>
  <div class="container mt-4">
    <h2>Welcome, Teenager!</h2>
    <Community />
    <EmailCenter />
    <SelfHelpTools />
  </div>
</template>

<script setup>
import Community from '../components/Community.vue'
import EmailCenter from '../components/EmailCenter.vue'
import SelfHelpTools from '../components/SelfHelpTools.vue'
</script>

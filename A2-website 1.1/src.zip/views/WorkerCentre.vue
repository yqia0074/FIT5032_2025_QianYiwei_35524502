<template>
  <div class="container mt-4">
    <h2>Welcome, Worker!</h2>
    <Community />
    <EmailCenter />
    <EmotionalSupportHub />
  </div>
</template>

<script setup>
import Community from '../components/Community.vue'
import EmailCenter from '../components/EmailCenter.vue'
import EmotionalSupportHub from '../components/EmotionalSupportHub.vue'
</script>



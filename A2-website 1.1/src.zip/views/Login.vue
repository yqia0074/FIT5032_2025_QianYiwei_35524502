<template>
  <div class="container mt-5">
    <h2>Login</h2>
    <form @submit.prevent="login">
      <div class="mb-3">
        <input v-model="email" type="email" placeholder="Email" class="form-control" required>
      </div>
      <div class="mb-3">
        <input v-model="password" type="password" placeholder="Password" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary">Login</button>
    </form>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const email = ref('')
const password = ref('')
const router = useRouter()

function login() {
  const user = JSON.parse(localStorage.getItem('user'))

  if (user && user.email === email.value && user.password === password.value) {
    if (user.role === 'teenager') {
      router.push('/teenager-centre')
    } else if (user.role === 'worker') {
      router.push('/worker-centre')
    } else if (user.role === 'admin') {
      router.push('/admin-centre')
    }
  } else {
    alert('Invalid email or password.')
  }
}
</script>

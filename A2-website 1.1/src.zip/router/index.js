import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import AuthHome from '../views/AuthHome.vue'
import Login from '../views/Login.vue'
import Register from '../views/Register.vue'
import TeenagerCentre from '../views/TeenagerCentre.vue'
import WorkerCentre from '../views/WorkerCentre.vue'
import AdminCentre from '../views/AdminCentre.vue'

const routes = [
  { path: '/', component: Home },
  { path: '/auth', component: AuthHome },
  { path: '/login', component: Login },
  { path: '/register', component: Register },
  {
    path: '/teenager-centre',
    component: TeenagerCentre,
    beforeEnter: (to, from, next) => {
      const user = JSON.parse(localStorage.getItem('user'))
      if (user?.role === 'teenager') next()
      else next('/auth')
    }
  },
  {
    path: '/worker-centre',
    component: WorkerCentre,
    beforeEnter: (to, from, next) => {
      const user = JSON.parse(localStorage.getItem('user'))
      if (user?.role === 'worker') next()
      else next('/auth')
    }
  },
  {
    path: '/admin-centre',
    component: AdminCentre,
    beforeEnter: (to, from, next) => {
      const user = JSON.parse(localStorage.getItem('user'))
      if (user?.role === 'admin') next()
      else next('/auth')
    }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router

<template>
  <div>
    <nav class="navbar navbar-expand navbar-light bg-light px-3">
      <a class="navbar-brand" href="#">Psych Support</a>
      <div class="collapse navbar-collapse">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <router-link to="/" class="nav-link">Home</router-link>
          </li>
          <li v-if="!user" class="nav-item">
            <router-link to="/auth" class="nav-link">Login / Register</router-link>
          </li>
          <li v-if="user?.role === 'teenager'" class="nav-item">
            <router-link to="/teenager-centre" class="nav-link">My Centre</router-link>
          </li>
          <li v-if="user?.role === 'worker'" class="nav-item">
            <router-link to="/worker-centre" class="nav-link">My Centre</router-link>
          </li>
          <li v-if="user?.role === 'admin'" class="nav-item">
            <router-link to="/admin-centre" class="nav-link">Admin</router-link>
          </li>
          <li v-if="user" class="nav-item">
            <a href="#" class="nav-link" @click.prevent="logout">Logout</a>
          </li>
        </ul>
      </div>
    </nav>
    <router-view />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'

const user = ref(null)

onMounted(() => {
  user.value = JSON.parse(localStorage.getItem('user'))
})

function logout() {
  localStorage.removeItem('user')
  location.reload()
}
</script>

<style>
body {
  background-color: #f8f9fa;
}
</style>



